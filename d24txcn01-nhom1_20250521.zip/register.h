#ifndef REGISTER_H
#define REGISTER_H

void registerUser();

#endif