#ifndef BACKUP_H
#define BACKUP_H

#include <string>

void checkAndBackup();  // Backup tu dong
void backupUsers();     // Backup thu cong

#endif